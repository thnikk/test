Step 1) Double press the reset button on the bottom of the Fightboard to put it in bootloader mode.
The button is recessed, so you may need to use something with a small tip like a pen to press the button.
When successful, the red LED should start pulsing.
Step 2) Run upload.bat right after entering bootloader mode. If successful, you should see some progress
bars in the command prompt along with "avrdude done. Thank you."
Step 3) If there are any problems, bug me on twitter @thnikk. I don't have a lot of experience with writing
batch scripts, so something may not work properly on your machine.